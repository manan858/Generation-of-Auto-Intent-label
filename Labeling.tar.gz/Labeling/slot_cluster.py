import codecs
import re
from nltk import word_tokenize, pos_tag
import numpy as np
from sklearn import cluster

word_cluster_num = 3

slot_list = {}
noun_num = {}
glove_noun_dict = {}
top_noun_num = {}
word_idx = {}
idx_word = {}
word_class = {}
class_word = {}

def extract_slots(file_dir):
    print('extracting slots...')
    index = 0
    with codecs.open(file_dir, 'r', encoding='utf8') as file:
        for lines in file.readlines():
            index += 1
            line = lines.strip().split('\t')
            intent = line[1]
            if intent == '10':
                labeled_sent = line[2]
                left = [i.start() for i in re.finditer('<', labeled_sent)]
                right = [i.start() for i in re.finditer('>', labeled_sent)]
                for i in range(0, len(left), 2):
                    slot_name = labeled_sent[left[i]+1:right[i]]
                    slot_value = labeled_sent[right[i]+2:left[i+1]-1]
                    if slot_name not in slot_list:
                        slot_list[slot_name] = set()
                    slot_list[slot_name].add(slot_value)
    for i in slot_list:
        print(i, '\n', str(slot_list[i]), '\n')

def make_dict(file_path):
    # noun_num = 0
    with codecs.open(file_path, 'r', encoding='utf8') as file:
        for lines in file.readlines():
            line = lines.strip().split('\t')
            intent = line[1]
            if intent == '10':
                sentence = word_tokenize(line[0])
                sentence = pos_tag(sentence)
                word, pos = zip(*sentence)
                for i in range(len(sentence)):
                    if pos[i][0] == 'N':
                        # noun_num += 1
                        if word[i] not in noun_num:
                            noun_num[word[i]] = 1
                        else:
                            noun_num[word[i]] += 1
    # del noun_num['i']
    # print(noun_num)

    sorted_noun = sorted(noun_num, key=lambda x:noun_num[x], reverse=True)
    for i in sorted_noun:
        if len(top_noun_num) >= 250:
            break
        word_idx[i] = len(top_noun_num)
        top_noun_num[i] = noun_num[i]
        print(i, str(top_noun_num[i]), str(word_idx[i]))

def cluster_word_byglove(glove_path = './data/glove.6B.300d.txt'):
    glove_list = []
    idx = 0
    # print(noun_num)
    with codecs.open(glove_path, 'r', encoding='utf8') as file:
        for lines in file.readlines():
            line = lines.strip().split(' ')
            word = line[0]
            vector = list(map(float, line[1:]))
            if word.lower() in noun_num:
                glove_noun_dict[word.lower()] = vector
                for i in range(noun_num[word.lower()]):
                    glove_list.append(vector)
                    idx_word[idx] = word.lower()
                    idx += 1
                # del noun_dict[word.lower()]
    # print(noun_num)
    glove_list = np.array(glove_list)
    print(glove_list.shape)
    # cluster_pred = cluster.SpectralClustering(n_clusters=60).fit_predict(X=glove_list)
    # cluster_pred = cluster.KMeans(n_clusters=50, max_iter=30000000).fit_predict(X=glove_list)
    class_pred = cluster.AgglomerativeClustering(n_clusters=word_cluster_num).fit_predict(X=glove_list)
    # print(np.array(cluster_pred).shape)
    # print(len(idx_word))
    for i in range(len(class_pred)):
        if class_pred[i] not in class_word:
            class_word[class_pred[i]] = set()
            # class_word[cluster_pred[i]] = []
        class_word[class_pred[i]].add(idx_word[i])
        # class_word[cluster_pred[i]].append(idx_word[i])
        if idx_word[i] not in word_class:
            word_class[idx_word[i]] = class_pred[i]
    for i in class_word:
        if len(class_word[i]) >= 1:
            print(str(i), ' ', len(class_word[i]), ' ', class_word[i])
    # for i in word_class:
    #     print(str(i), ' ', word_class[i])

def slot_clustering(file_path):
    print('making noun_num dict...')
    make_dict(file_path)
    print('clustering noun by glove embedding...')
    cluster_word_byglove()

if __name__ == '__main__':
    test = './data/atis_test_merge.txt'
    # extract_slots(test)
    slot_clustering(test)