import codecs
import numpy as np
from nltk import word_tokenize, pos_tag
import json

def preprocess_data(in_file_path, out_file_path):
    with codecs.open(in_file_path, 'r', encoding='utf8') as file:
        target_file = codecs.open(out_file_path, 'w', encoding='utf8')
        sent_dicts = []
        intent_dict = {}
        for lines in file.readlines():
            line = lines.strip().split('\t')
            intents = line[1].split(' ')
            if intents[0] in intent_dict:
                intent_dict[intents[0]] += 1
            else:
                intent_dict[intents[0]] = 1
            d = {}
            d['query'] = line[0]
            sent_dicts.append(d)
            # target_file.write(line[0] + '\t' + intent[0] + '\n')
        print(intent_dict)
        print(len(intent_dict))
        # json.dump(sent_dicts, target_file)

def merge_data(in_file_path1, in_file_path2, out_file_path):
    with codecs.open(in_file_path1, 'r', encoding='utf8') as file1:
        with codecs.open(in_file_path2, 'r', encoding='utf8') as file2:
            target_file = codecs.open(out_file_path, 'w', encoding='utf8')
            intent_index = {}
            index = 0
            for lines in file1.readlines():
                line = lines.strip().split('\t')
                intents = line[1].split(' ')
                if intents[0] not in intent_index:
                    intent_index[intents[0]] = index
                    index += 1
                target_file.write(line[0] + '\t' + str(intent_index[intents[0]]) + '\t' + line[2] + '\t')
                embed = file2.readline().strip()
                target_file.write(embed + '\n')
            print(index)

def make_data(file_path):
    X = []
    Y = []
    with codecs.open(file_path, 'r', encoding='utf8') as file:
        for lines in file.readlines():
            line = lines.strip().split('\t')
            embed = line[3].split('|')
            X.append(embed)
            Y.append(int(line[1]))
        X = np.array(X)
        Y = np.array(Y)
    return X, Y

if __name__ == '__main__':
    train_in = './data/atis.train.tsv'
    train_out = './data/atis.train.json'
    test_in = './data/atis.test.tsv'
    test_out = './data/atis.test.json'
    # preprocess_data(train_in, train_out)
    # preprocess_data(test_in, test_out)
    total_in = './data/atis.total.tsv'
    total_embed = './data/atis_total_encoding.txt'
    total_merge = './data/atis_total_merge.txt'
    merge_data(total_in, total_embed, total_merge)