
from preprocess import make_data
import tensorflow as tf

def NN_classifier(train_dir, test_dir):
    train_X, train_Y = make_data(train_dir)
    test_X, test_Y = make_data(test_dir)

    embed_num = 100
    hidden_num = 50
    class_num = 18
    regularization_rate = 0.0001
    learning_rate_base = 0.1
    learning_rate_decay = 0.99
    global_step = tf.Variable(0, trainable=False)
    w_1 = tf.get_variable('w_1', [embed_num, hidden_num])
    b_1 = tf.get_variable('b_1', [hidden_num])
    w_2 = tf.get_variable('w_2', [hidden_num, class_num])
    b_2 = tf.get_variable('b_2', [class_num])
    x = tf.placeholder(tf.float32, [None, embed_num])
    y_label = tf.placeholder(tf.int64, [None])

    hidden_1 = tf.nn.relu(tf.matmul(x, w_1) + b_1)
    y_logit = tf.matmul(hidden_1, w_2) + b_2
    cross_entropy = tf.nn.sparse_softmax_cross_entropy_with_logits(logits=y_logit, labels=y_label)
    cross_entropy_mean = tf.reduce_mean(cross_entropy)
    regularizer = tf.contrib.layers.l2_regularizer(regularization_rate)
    regularization = regularizer(w_1) + regularizer(w_2)
    loss = cross_entropy_mean + regularization
    # loss = cross_entropy_mean
    learning_rate = tf.train.exponential_decay(
        learning_rate_base,
        global_step,
        1,
        learning_rate_decay
    )
    train_step = tf.train.AdamOptimizer(learning_rate).minimize(loss, global_step=global_step)

    with tf.Session() as sess:
        tf.global_variables_initializer().run()
        for i in range(300):
            train_step.run({x:train_X, y_label:train_Y})
            correct_prediction = tf.equal(tf.argmax(y_logit, axis=1), y_label)
            accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
            print('train loss: ', loss.eval({x:train_X, y_label:train_Y}))
            print('train acc: ', accuracy.eval({x:train_X, y_label:train_Y}))
            # print(learning_rate.eval())
            # print(global_step.eval())
            print('test acc: ', accuracy.eval({x:test_X, y_label:test_Y}))


if __name__ == '__main__':
    train_dir = './data/atis_train_merge.txt'
    test_dir = './data/atis_test_merge.txt'
    NN_classifier(train_dir, test_dir)