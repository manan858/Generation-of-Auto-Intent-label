
import codecs
import pickle
import numpy as np
import tensorflow as tf

vocab_dict = {}
max_len = 50
train_size = 4978
regularization_rate = 0.0001
learning_rate_base = 0.1
learning_rate_decay = 0.99

def word_to_idx(word):
    if word not in vocab_dict:
        vocab_dict[word] = len(vocab_dict)
    return vocab_dict[word]

def padding(sentence):
    sentence = [word_to_idx(x) for x in sentence.strip().split(' ')]
    sentence = sentence + ([0] * (max_len - len(sentence)))
    return sentence

def make_data(file_path):
    X_len = []
    X = []
    Y = []
    with codecs.open(file_path, 'r', encoding='utf8') as file:
        for lines in file.readlines():
            line = lines.strip().split('\t')
            X_len.append(len(line[0]))
            X.append(padding(line[0].lower()))
            Y.append(line[1])
        X_len = np.array(X_len)
        X = np.array(X)
        Y = np.array(Y)
    print('X_data', np.shape(X))
    print('X_len_data', np.shape(X_len))
    print('Y_data', np.shape(Y))
    return X, Y, X_len

def generate_glove_embedding(glove_path = './data/glove.6B.300d.txt', glove_dim = 300):
    print('vocab len is %d' % len(vocab_dict))
    glove_embedding = np.random.rand(len(vocab_dict), glove_dim).astype('float32')
    found = 0
    with codecs.open(glove_path, 'r', encoding='utf8') as file:
        for lines in file.readlines():
            line = lines.strip().split(' ')
            word = line[0]
            vector = list(map(float, line[1:]))
            if word.lower() in vocab_dict:
                idx = vocab_dict[word]
                glove_embedding[idx] = vector
                found += 1
    print('found ' + str(found) + ' on vocab from glove.')
    print(np.shape(glove_embedding))
    return glove_embedding

def bi_rnn(inputs, lengths):
    fw_cell = tf.contrib.rnn.GRUCell(100)
    bw_cell = tf.contrib.rnn.GRUCell(100)
    _, (state_fw, state_bw) = tf.nn.bidirectional_dynamic_rnn(fw_cell,
                                                            bw_cell,
                                                            inputs,
                                                            sequence_length=lengths,
                                                            dtype=tf.float32)
    print('state ', state_bw.get_shape())
    result = tf.concat([state_fw, state_bw], axis=1)
    return result

def build_network():
    train_X, train_Y, train_X_len = make_data('./data/atis_train_merge.txt')
    test_X, test_Y, test_X_len = make_data('./data/atis_test_merge.txt')

    X = tf.placeholder(tf.int64, [None, None])
    print('X ', X.get_shape())
    X_len = tf.placeholder(tf.int64, [None])
    print('X_len ', X_len.get_shape())
    y_label = tf.placeholder(tf.int64, [None])

    glove_embedding = generate_glove_embedding()
    print('glove_embedding ', np.shape(glove_embedding))
    with tf.device('/cpu:0'):
        word_embed = tf.get_variable(name='word_embed', initializer=glove_embedding, trainable=True)
    X_embedding = tf.nn.embedding_lookup(word_embed, X)
    print('X_embedding ', X_embedding.get_shape())
    X_sent_vec = bi_rnn(X_embedding, X_len)
    print('X_sent_vec ', X_sent_vec.get_shape())

    global_step = tf.Variable(0, trainable=False)
    w_1 = tf.get_variable('w_1', [200, 50])
    b_1 = tf.get_variable('b_1', [50])
    w_2 = tf.get_variable('w_2', [50, 18])
    b_2 = tf.get_variable('b_2', [18])

    hidden_1 = tf.nn.relu(tf.matmul(X_sent_vec, w_1) + b_1)
    y_logit = tf.matmul(hidden_1, w_2) + b_2
    cross_entropy = tf.nn.sparse_softmax_cross_entropy_with_logits(logits=y_logit, labels=y_label)
    cross_entropy_mean = tf.reduce_mean(cross_entropy)
    regularizer = tf.contrib.layers.l2_regularizer(regularization_rate)
    regularization = regularizer(w_1) + regularizer(w_2)
    loss = cross_entropy_mean + regularization
    learning_rate = tf.train.exponential_decay(
        learning_rate_base,
        global_step,
        1,
        learning_rate_decay
    )
    train_step = tf.train.AdamOptimizer(learning_rate).minimize(loss, global_step=global_step)

    with tf.Session() as sess:
        tf.global_variables_initializer().run()
        for i in range(300):
            train_step.run({X:train_X, X_len:train_X_len, y_label:train_Y})
            correct_prediction = tf.equal(tf.argmax(y_logit, axis=1), y_label)
            accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
            print('train loss: ', loss.eval({X:train_X, X_len:train_X_len, y_label:train_Y}))
            print('train acc: ', accuracy.eval({X:train_X, X_len:train_X_len, y_label:train_Y}))
            # print(learning_rate.eval())
            # print(global_step.eval())
            print('test acc: ', accuracy.eval({X:test_X, X_len:test_X_len, y_label:test_Y}))

if __name__ == '__main__':
    build_network()