
from preprocess import make_data
from sklearn import cluster
from sklearn.metrics import accuracy_score
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import normalize
import warnings
import codecs

def kmeans(test_X, test_Y):

    # file1 = codecs.open('./data/kmeans/train_Y.txt', 'w', encoding='utf8')
    # file2 = codecs.open('./data/kmeans/train_pred.txt', 'w', encoding='utf8')
    file3 = codecs.open('./data/kmeans/test_Y.txt', 'w', encoding='utf8')
    # file4 = codecs.open('./data/kmeans/test_pred.txt', 'w', encoding='utf8')
    file5 = codecs.open('./data/kmeans/test_fitpred.txt', 'w', encoding='utf8')

    # train_X = normalize(train_X)
    test_X = normalize(test_X)
    # model = cluster.KMeans(n_clusters=17, max_iter=30000000).fit(X=train_X)
    # test_pred = model.predict(test_X)
    test_fitpred = cluster.KMeans(n_clusters=16, max_iter=30000000).fit_predict(X=test_X)

    # for i in train_Y:
    #     file1.write(str(i) + '\n')
    # for i in model.labels_:
    #     file2.write(str(i) + '\n')
    for i in test_Y:
        file3.write(str(i) + '\n')
    # for i in test_pred:
    #     file4.write(str(i) + '\n')
    for i in test_fitpred:
        file5.write(str(i) + '\n')

    print('KMeans clustering finished.')

def DBSCAN(test_X, test_Y):

    # file1 = codecs.open('./data/DBSCAN/train_Y.txt', 'w', encoding='utf8')
    # file2 = codecs.open('./data/DBSCAN/train_pred.txt', 'w', encoding='utf8')
    file3 = codecs.open('./data/DBSCAN/test_Y.txt', 'w', encoding='utf8')
    file5 = codecs.open('./data/DBSCAN/test_fitpred.txt', 'w', encoding='utf8')

    # train_X = normalize(train_X)
    test_X = normalize(test_X)
    # model = cluster.DBSCAN().fit(X=train_X)
    test_fitpred = cluster.DBSCAN().fit_predict(X=test_X)

    # for i in train_Y:
    #     file1.write(str(i) + '\n')
    # for i in model.labels_:
    #     file2.write(str(i) + '\n')
    for i in test_Y:
        file3.write(str(i) + '\n')
    for i in test_fitpred:
        file5.write(str(i) + '\n')

    print('DBSCAN clustering finished.')

def Agglo(test_X, test_Y):

    # file1 = codecs.open('./data/Agglo/train_Y.txt', 'w', encoding='utf8')
    # file2 = codecs.open('./data/Agglo/train_pred.txt', 'w', encoding='utf8')
    file3 = codecs.open('./data/Agglo/test_Y.txt', 'w', encoding='utf8')
    file5 = codecs.open('./data/Agglo/test_fitpred.txt', 'w', encoding='utf8')

    # train_X = normalize(train_X)
    test_X = normalize(test_X)
    # model = cluster.AgglomerativeClustering(n_clusters=17).fit(X=train_X)
    test_fitpred = cluster.AgglomerativeClustering(n_clusters=16).fit_predict(X=test_X)

    # for i in train_Y:
    #     file1.write(str(i) + '\n')
    # for i in model.labels_:
    #     file2.write(str(i) + '\n')
    for i in test_Y:
        file3.write(str(i) + '\n')
    for i in test_fitpred:
        file5.write(str(i) + '\n')

    print('Agglomerative clustering finished.')

def spectral(test_X, test_Y):

    # file1 = codecs.open('./data/spectral/train_Y.txt', 'w', encoding='utf8')
    # file2 = codecs.open('./data/spectral/train_pred.txt', 'w', encoding='utf8')
    file3 = codecs.open('./data/spectral/test_Y.txt', 'w', encoding='utf8')
    file5 = codecs.open('./data/spectral/test_fitpred.txt', 'w', encoding='utf8')

    # train_X = normalize(train_X)
    # test_X = normalize(test_X)
    # model = cluster.SpectralClustering(n_clusters=17).fit(X=train_X)
    test_fitpred = cluster.SpectralClustering(n_clusters=17).fit_predict(X=test_X)

    # for i in train_Y:
    #     file1.write(str(i) + '\n')
    # for i in model.labels_:
    #     file2.write(str(i) + '\n')
    for i in test_Y:
        file3.write(str(i) + '\n')
    for i in test_fitpred:
        file5.write(str(i) + '\n')

    print('Spectral clustering finished.')

def birch(test_X, test_Y):

    # file1 = codecs.open('./data/birch/train_Y.txt', 'w', encoding='utf8')
    # file2 = codecs.open('./data/birch/train_pred.txt', 'w', encoding='utf8')
    file3 = codecs.open('./data/birch/test_Y.txt', 'w', encoding='utf8')
    # file4 = codecs.open('./data/birch/test_pred.txt', 'w', encoding='utf8')
    file5 = codecs.open('./data/birch/test_fitpred.txt', 'w', encoding='utf8')

    # train_X = normalize(train_X)
    test_X = normalize(test_X)
    # model = cluster.Birch(n_clusters=17).fit(X=train_X)
    # test_pred = model.predict(test_X)
    test_fitpred = cluster.Birch(n_clusters=16).fit_predict(X=test_X)

    # for i in train_Y:
    #     file1.write(str(i) + '\n')
    # for i in model.labels_:
    #     file2.write(str(i) + '\n')
    for i in test_Y:
        file3.write(str(i) + '\n')
    # for i in test_pred:
    #     file4.write(str(i) + '\n')
    for i in test_fitpred:
        file5.write(str(i) + '\n')

    print('Birch clustering finished.')

def distance(test_X, test_Y):
    sum_all = 0.0
    num_all = 0.0
    sum = 0.0
    num = 0.0
    for y_1 in range(len(test_Y)):
        for y_2 in range(y_1+1, len(test_Y)):
            cos_sim_all = cosine_similarity(test_X[y_1], test_X[y_2])
            sum_all += cos_sim_all[0][0]
            num_all += 1.0
            print('all ' + str(sum_all/num_all))
            if test_Y[y_1] == test_Y[y_2]:
                cos_sim = cosine_similarity(test_X[y_1], test_X[y_2])
                sum += cos_sim[0][0]
                num += 1.0
                print('same ' + str(sum/num))

def do_cluster(test_X, test_Y):
    # kmeans(test_X, test_Y)
    # DBSCAN(test_X, test_Y)
    # Agglo(test_X, test_Y)
    spectral(test_X, test_Y)
    # birch(test_X, test_Y)


if __name__ == '__main__':
    train = './data/atis_train_merge.txt'
    test = './data/atis_test_merge.txt'
    train_X, train_Y = make_data(train)
    test_X, test_Y = make_data(test)
    do_cluster(test_X, test_Y)
    # warnings.filterwarnings("ignore", category=DeprecationWarning)
    # distance(train_X, train_Y, test_X, test_Y)