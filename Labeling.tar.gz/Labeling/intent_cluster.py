
import codecs
from nltk import word_tokenize, pos_tag
import numpy as np
from sklearn import cluster
import preprocess
import clustering
import count

word_cluster_num = 55

noun_num = {}
glove_noun_dict = {}
top_noun_num = {}
word_idx = {}
idx_word = {}
word_class = {}
class_word = {}

def make_dict(file_path):
    # noun_num = 0
    with codecs.open(file_path, 'r', encoding='utf8') as file:
        for lines in file.readlines():
            line = lines.strip().split('\t')
            sentence = word_tokenize(line[0])
            sentence = pos_tag(sentence)
            word, pos = zip(*sentence)
            for i in range(len(sentence)):
                if pos[i][0] == 'N':
                    # noun_num += 1
                    if word[i] not in noun_num:
                        noun_num[word[i]] = 1
                    else:
                        noun_num[word[i]] += 1
    # del noun_num['i']
    # print(noun_num)

    sorted_noun = sorted(noun_num, key=lambda x:noun_num[x], reverse=True)
    for i in sorted_noun:
        if len(top_noun_num) >= 250:
            break
        word_idx[i] = len(top_noun_num)
        top_noun_num[i] = noun_num[i]
        print(i, str(top_noun_num[i]), str(word_idx[i]))

def make_data_bycount(file_path):
    matrix = []
    idx = 0
    with codecs.open(file_path, 'r', encoding='utf8') as file:
        for lines in file.readlines():
            line = lines.strip().split('\t')
            sentence = word_tokenize(line[0])
            feature = np.zeros([120], dtype='int32')
            idx += 1
            for word in sentence:
                if word in top_noun_num:
                    feature[word_idx[word]] = top_noun_num[word]
            matrix.append(feature)
    matrix = np.array(matrix)
    return matrix

def make_data_bygloveclass(file_path):
    matrix = []
    idx = 0
    with codecs.open(file_path, 'r', encoding='utf8') as file:
        for lines in file.readlines():
            line = lines.strip().split('\t')
            sentence = word_tokenize(line[0])
            feature = np.zeros([word_cluster_num], dtype='int32')
            idx += 1
            for word in sentence:
                if word in word_class:
                    feature[word_class[word]] += noun_num[word]
            matrix.append(feature)
    matrix = np.array(matrix)
    # for line in matrix:
    #     print(str(line))
    return matrix

def cluster_word_byglove(glove_path = './data/glove.6B.300d.txt'):
    glove_list = []
    idx = 0
    with codecs.open(glove_path, 'r', encoding='utf8') as file:
        for lines in file.readlines():
            line = lines.strip().split(' ')
            word = line[0]
            vector = list(map(float, line[1:]))
            if word.lower() in noun_num:
                glove_noun_dict[word.lower()] = vector
                for i in range(noun_num[word.lower()]):
                    glove_list.append(vector)
                    idx_word[idx] = word.lower()
                    idx += 1
                # del noun_dict[word.lower()]
    # print(noun_dict)
    glove_list = np.array(glove_list)
    # print(glove_list.shape)
    # cluster_pred = cluster.SpectralClustering(n_clusters=60).fit_predict(X=glove_list)
    # cluster_pred = cluster.KMeans(n_clusters=50, max_iter=30000000).fit_predict(X=glove_list)
    class_pred = cluster.AgglomerativeClustering(n_clusters=word_cluster_num).fit_predict(X=glove_list)
    # print(np.array(cluster_pred).shape)
    # print(len(idx_word))
    for i in range(len(class_pred)):
        if class_pred[i] not in class_word:
            class_word[class_pred[i]] = set()
            # class_word[cluster_pred[i]] = []
        class_word[class_pred[i]].add(idx_word[i])
        # class_word[cluster_pred[i]].append(idx_word[i])
        if idx_word[i] not in word_class:
            word_class[idx_word[i]] = class_pred[i]
    for i in class_word:
        print(str(i), ' ', len(class_word[i]), ' ', class_word[i])
    for i in word_class:
        print(str(i), ' ', word_class[i])

def do_cluster_bycount(test_dir):
    print('making noun_num dict...')
    make_dict(test_dir)
    print('generating X data...')
    test_X = make_data_bycount(test_dir)
    print('generating Y data...')
    _, test_Y = preprocess.make_data(test_dir)

    print('making noun_num dict...')
    clustering.do_cluster(test_X, test_Y)
    print(test_X)
    print(test_X.shape)
    count.show_same()

def do_cluster_bygloveclass(test_dir):
    print('making noun_num dict...')
    make_dict(test_dir)
    print('clustering noun by glove embedding...')
    cluster_word_byglove()
    print('generating X data...')
    test_X = make_data_bygloveclass(test_dir)
    print('generating Y data...')
    _, test_Y = preprocess.make_data(test_dir)

    print('clustering...')
    clustering.do_cluster(test_X, test_Y)
    print(test_X)
    print(test_X.shape)
    count.show_same()

if __name__ == '__main__':
    train_dir = './data/atis_train_merge.txt'
    test_dir = './data/atis_test_merge.txt'
    # make_dict(test_dir)
    # do_cluster_bycount(test_dir)
    do_cluster_bygloveclass(test_dir)