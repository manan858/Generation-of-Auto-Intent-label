import codecs
import os
import itertools
import math

target_file = codecs.open('./data/result_stat', 'w', encoding='utf8')

def count_intent(file_path, size):
    intent_dict = {}
    sorted_dict = {}
    with codecs.open(file_path, 'r', encoding='utf8') as file:
        for lines in file.readlines():
            line = lines.strip().split('\t')
            intents = line[1].strip().split(' ')
            if intents[0] not in intent_dict:
                intent_dict[intents[0]] = 1.0
            else:
                intent_dict[intents[0]] += 1.0
    print(len(intent_dict))
    print(intent_dict)
    # for a, b in sorted(intent_dict.items(), key=lambda x:x[1], reverse=True):
    #     sorted_dict[a] = b
    # print(sorted(intent_dict.items(), key=lambda x:x[1], reverse=True))
    for i in intent_dict:
        print('%s\t%d\t%.2f%%' % (i, int(intent_dict[i]), intent_dict[i] / size * 100.0))

def count_line_len(file_path):
    max_len = 0
    with codecs.open(file_path, 'r', encoding='utf8') as file:
        for lines in file.readlines():
            line = lines.strip().split('\t')
            if len(line[0].strip().split(' ')) > max_len:
                max_len = len(line[0].strip().split(' '))
    print(max_len)

def count_label(model, file_name, size, dir_path = './data'):
    file_path = os.path.join(dir_path, model, file_name)
    intent_dict = {}
    with codecs.open(file_path, 'r', encoding='utf8') as file:
        for lines in file.readlines():
            intent = lines.strip()
            if intent not in intent_dict:
                intent_dict[intent] = 1.0
            else:
                intent_dict[intent] += 1.0
    print(intent_dict)
    for i in intent_dict:
        print('%s\t%d\t%.2f%%' % (i, int(intent_dict[i]), intent_dict[i] / size * 100.0))
        target_file.write('%s\t%d\t%.2f%%\n' % (i, int(intent_dict[i]), intent_dict[i] / size * 100.0))

def print_label_stat():
    train_pred = 'train_pred.txt'
    test_pred = 'test_pred.txt'
    test_fitpred = 'test_fitpred.txt'

    target_file.write('\n------------------------kmeans------------------------\n')
    print('\n------------------------kmeans------------------------\n')
    count_label('kmeans', train_pred, 4979.0)
    count_label('kmeans', test_pred, 894.0)
    count_label('kmeans', test_fitpred, 894.0)

    target_file.write('\n------------------------DBSCAN------------------------\n')
    print('\n------------------------DBSCAN------------------------\n')
    count_label('DBSCAN', train_pred, 4979.0)
    count_label('DBSCAN', test_fitpred, 894.0)

    target_file.write('\n------------------------Agglo-------------------------\n')
    print('\n------------------------Agglo-------------------------\n')
    count_label('Agglo', train_pred, 4979.0)
    count_label('Agglo', test_fitpred, 894.0)

    target_file.write('\n-----------------------spectral-----------------------\n')
    print('\n-----------------------spectral-----------------------\n')
    count_label('spectral', train_pred, 4979.0)
    count_label('spectral', test_fitpred, 894.0)

    target_file.write('\n------------------------birch-------------------------\n')
    print('\n------------------------birch-------------------------\n')
    count_label('birch', train_pred, 4979.0)
    count_label('birch', test_pred, 894.0)
    count_label('birch', test_fitpred, 894.0)


def intent_dict(label_dir, logit_dir):
    label_file = codecs.open(label_dir, 'r', encoding='utf8')
    logit_file = codecs.open(logit_dir, 'r', encoding='utf8')
    label_dict = {}
    logit_dict = {}

    index = 1
    for lines in label_file.readlines():
        intent = int(lines.strip())
        if intent not in label_dict:
            label_dict[intent] = []
        label_dict[intent].append(index)
        index += 1
    label_dict[15] = label_dict[17]
    del label_dict[17]
    # for i in label_dict:
    #     print(str(i) + str(label_dict[i]))
    # sorted_label = sorted(label_dict, key=lambda x:label_dict[x])
    # print(str(sorted_label))

    index = 1
    for lines in logit_file.readlines():
        intent = int(lines.strip())
        if intent not in logit_dict:
            logit_dict[intent] = []
        logit_dict[intent].append(index)
        index += 1
    # for i in logit_dict:
    #     print(str(i) + str(logit_dict[i]))
    # sorted_logit = sorted(logit_dict, key=lambda x:logit_dict[x])
    # print(str(sorted_logit))
    # print('\n')

    return label_dict, logit_dict


def enum_acc(label_dir, logit_dir):
    label_dict, logit_dict = intent_dict(label_dir, logit_dir)
    # correct = 0
    # for i in range(16):
    #     intersection = len(set(label_dict[sorted_label[i]]).intersection(set(logit_dict[sorted_logit[i]])))
    #     # print(intersection)
    #     correct += intersection
    # print(str(correct) + ' ' + str(float(correct) / 894.0))
    permutations = itertools.permutations(range(16), 16)
    max_correct = 0
    iter = 0.0
    all_iter = float(math.factorial(16))
    # print(len(label_dict[0]))
    for arr in permutations:
        correct = 0
        arr = list(arr)
        # print(len(logit_dict[arr[0]]))
        iter += 1.0
        # print('%f' % (iter/all_iter*100.0))
        for i in range(16):
            intersection = len(set(label_dict[i]).intersection(set(logit_dict[arr[i]])))
            # print(intersection)
            correct += intersection
        if correct > max_correct:
            max_correct = correct
            print(str(arr) + ' ' + str(max_correct) + ' ' + str(float(max_correct) / 894.0))

def enum_same(label_dir, logit_dir):
    label_dict, logit_dict = intent_dict(label_dir, logit_dir)
    same_dict = {}
    for i in label_dict:
        same_dict[i] = []
        for j in logit_dict:
            same_dict[i].append(len(set(label_dict[i]).intersection(set(logit_dict[j]))))
    for i in same_dict:
        print(same_dict[i])

def show_same():
    # label = './data/Agglo/test_Y.txt'
    # logit = './data/Agglo/test_fitpred.txt'
    # print('\n------------------------Agglo-------------------------\n')
    # enum_same(label, logit)

    label = './data/spectral/test_Y.txt'
    logit = './data/spectral/test_fitpred.txt'
    print('\n------------------------spectral----------------------\n')
    enum_same(label, logit)

    # label = './data/birch/test_Y.txt'
    # logit = './data/birch/test_fitpred.txt'
    # print('\n------------------------birch-------------------------\n')
    # enum_same(label, logit)
    #
    # label = './data/DBSCAN/test_Y.txt'
    # logit = './data/DBSCAN/test_fitpred.txt'
    # print('\n------------------------DBSCAN------------------------\n')
    # enum_same(label, logit)
    #
    # label = './data/kmeans/test_Y.txt'
    # logit = './data/kmeans/test_fitpred.txt'
    # print('\n------------------------kmeans------------------------\n')
    # enum_same(label, logit)


if __name__ == '__main__':
    train = './data/atis.train.tsv'
    test = './data/atis.test.tsv'
    # count_line_len(train)
    # count_line_len(test)
    # count_intent(train, 4979.0)
    # count_intent(test, 894.0)
    # print_label_stat()
    show_same()